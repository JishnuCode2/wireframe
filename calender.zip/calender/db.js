import firebase from 'firebase';


const firebaseConfig={
  apiKey: "AIzaSyASPjarDvfleII-RMSYJ0gU-qsopEfTvYQ",
  authDomain: "calender-app-90d85.firebaseapp.com",
  projectId: "calender-app-90d85",
  storageBucket: "calender-app-90d85.appspot.com",
  messagingSenderId: "760776120236",
  appId: "1:760776120236:web:3b79b017d6aa6ec87bcc09"
};


firebase.initializeApp(firebaseConfig);

export default firebase.firestore()