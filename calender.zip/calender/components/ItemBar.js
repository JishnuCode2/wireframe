import React,{Component} from 'react';
import {View,Text,StyleSheet,TouchableOpacity,KeyboardAvoidingView,SafeAreaView,StatusBar,Platform}  from 'react-native';
import {RFValue} from 'react-native-responsive-fontsize';
import {IonIcons} from "react-native-vector-icons/Ionicons";
export default class ItemBar extends Component{

  render(){
    return(
              <KeyboardAvoidingView style={{width:"100%",height:"100%",backgroundColor:"grey"}} behavior="padding">
         <SafeAreaView style={styles.droidSafearea}/>
         <View style={{width:"80%",height:"100%",backgroundColor:"white"}}>
         <TouchableOpacity style={{height:30,width:30,marginLeft:10}} 
         onPress={()=>this.setState({showTabs:false})}>
          <Text style={{marginTop:-10,alignSelf:'center'}}>____</Text>
       <Text style={{alignSelf:'center',marginTop:-10}}>____</Text>
          <Text style={{marginTop:-10,alignSelf:'center'}}>____</Text>

         </TouchableOpacity>
         
         <View style={{width:"100%",backgroundColor:'black',height:1,marginTop:20}}> {' '}</View>
         <TouchableOpacity style={{marginTop:20,marginLeft:20}}
          onPress={()=>this.props.onPressHome}>
          <Text style={{fontSize:20,fontWeight:"bold"}}>Home</Text>
        </TouchableOpacity>
        <View style={{width:"100%",backgroundColor:'black',height:1,marginTop:20}}> {' '}</View>
         <TouchableOpacity style={{marginTop:20,marginLeft:20}}
          onPress={()=>this.props.onPressSettings}>
 
          <Text style={{fontSize:20,fontWeight:"bold"}}>Settings</Text>
        </TouchableOpacity>
        <View style={{width:"100%",backgroundColor:'black',height:1,marginTop:20}}> {' '}</View>
        </View>
         </KeyboardAvoidingView>
    )
  }

}     

const styles = StyleSheet.create({
  droidSafearea:{
     height: Platform.OS === "android"? StatusBar.currentHeight: 0
  }
})