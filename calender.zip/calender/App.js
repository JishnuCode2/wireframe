import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import {createAppContainer, createSwitchNavigator} from 'react-navigation'
import SignInScreen from './screens/SignInScreen'
import DetailsScreen from './screens/Details'
import Introductions from './screens/IntroductionScreen'
import SignUpScreen from './screens/SignUp'
import HomeScreen from './screens/Home'

import Calender from './screens/Calender'
import TimeTable from './screens/TimeTable'
export default class App extends React.Component {
  render(){
      return (<SwitchNavigator/>);
  }

}



const AppSwitchNavigator = createSwitchNavigator(
  {SignInScreen:
    {screen: SignInScreen},
   DetailsScreen:
    {screen: DetailsScreen},
   IntroductionScreen:{
     screen: Introductions
   },
   SignUpScreen:{
     screen: SignUpScreen
   },
   HomeScreen:{
     screen: HomeScreen
   },

   Calender:{
     screen: Calender
   },
   TimeTable:{
     screen: TimeTable
   }
  },

  {initialRouteName: 'IntroductionScreen'}
)

const SwitchNavigator = createAppContainer(AppSwitchNavigator)
