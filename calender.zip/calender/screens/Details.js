import React,{Component} from 'react'
import {View,Text,SafeAreaView,StyleSheet,Platform,StatusBar,TouchableOpacity} from 'react-native'
import {RFValue} from 'react-native-responsive-fontsize'
export default class DetailsScreen extends Component{
   render(){
     return(
        <View style={{flex:1,alignItems:'center',backgroundColor:'gray',height:'100%'}}>
         <SafeAreaView style={styles.droidSafearea}/>
         <Text style={{marginTop:RFValue(30),fontSize:RFValue(20),fontStyle:'italic'}}>Details</Text>
         <View style={styles.container}>
          <Text style={styles.text}>1. Please follow all given instructions </Text>
         </View>
         <View style={styles.container}>
          <Text style={styles.text}>2. Please fill up all the fields in the forms </Text>
         </View>
         <View style={styles.container}>
          <Text style={styles.text}>3. Please create calendar/timetable before viewing them </Text>
         </View>
         <TouchableOpacity style={styles.buttonContainer}
         onPress={
          this.props.navigation.getParam('type') === "fromHome" ? 
          ()=>this.props.navigation.navigate('HomeScreen')
          : ()=>this.props.navigation.navigate('IntroductionScreen')
         }>

             <Text style={{fontSize:RFValue(15)}}> Go Back </Text>

         </TouchableOpacity>

        </View>
     )
   }
}

const styles = StyleSheet.create({
  droidSafearea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
    },
  text:{
    alignSelf:'flex-start',
    marginLeft:50
  },
  container:{width:'100%',marginTop:RFValue(50)},
  buttonContainer:{
    width:'30%',
    height:RFValue(40),
    backgroundColor:'yellow',
    marginTop:RFValue(80),
    alignItems:'center',
    borderRadius:100,
    justifyContent:'center'
  }
})