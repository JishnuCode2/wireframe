import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  ImageBackground,
  SafeAreaView,
  Platform,
  TouchableOpacity,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import db from '../db.js'
export default class SignInScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      confirmPassword: false,
      password: '',
      emailId: '',
      enter: 'Email Id',
      confirm:'',
      userId:''
    };
  }

  registerUser = () =>{
    const{userId,password,emailId,confirm} = this.state
    console.log(userId,password)
     db.collection("users")
       .doc(userId)
       .set({
          user_id:userId,
          email_id:emailId,
          password:password
       });
  
         this.props.navigation.navigate('HomeScreen',{userId:userId})
  
  
  }

  checkPassword = async() =>{
    const password = await db
        .collection('users')
        .where('password','==',this.state.password)
        .get()
      console.log(password.docs.length)
    var isnotEligible
    if(password.docs.length === 0){
       isnotEligible = false
    }
    else{
      isnotEligible = true
    }
    return isnotEligible
  }
  checkUserId = async() =>{
    const user = await db
        .collection('users')
        .where('user_id','==',this.state.userId)
        .get()

    var isnotEligible
    if(user.docs.length === 0){
       isnotEligible = false
    }
    else{
      isnotEligible = true
    }
    return isnotEligible 
  }
  render() {
    const { confirmPassword, enter } = this.state;
    if (enter === 'Email Id') {
      return (
        <ImageBackground
          source={require('../assets/bgImg1.png')}
          style={styles.backgroundImage}>
          <KeyboardAvoidingView style={styles.container}>
            <SafeAreaView />
            <View style={styles.heading}>
              <Text style={styles.headingText}>Sign Up</Text>
            </View>
            <View style={styles.buttonContainer}>
              <TextInput
                placeholder="Enter your Email Id"
                style={styles.textInput}
                onChangeText ={(text)=>this.setState({emailId : text})}
              />
              <TouchableOpacity
                style={{ alignItems: 'center', justifyContent: 'center' }}
                onPress={() => this.setState({ enter: 'User Id' })}>
                <Text style={styles.textContainer}>Submit</Text>
              </TouchableOpacity>
            </View>
            <View>
              <Text style={{ fontSize: 20, alignSelf: 'center' }}>
                {'<1/4>'}
              </Text>
            </View>
          </KeyboardAvoidingView>
        </ImageBackground>
      );
    }
    if (enter === 'User Id') {
      return (
        <ImageBackground
          source={require('../assets/bgImg1.png')}
          style={styles.backgroundImage}>
          <KeyboardAvoidingView style={styles.container}>
            <SafeAreaView />
            <View style={styles.heading}>
              <Text style={styles.headingText}>Sign Up</Text>
            </View>
             <View style={[styles.buttonContainer,{height:"37.5%"}]}>
              <TextInput
                placeholder="Enter your Email Id"
                style={styles.textInput}
                value={this.state.emailId}
              />
            </View>
            <View style={[styles.buttonContainer,{height:"37.5%"}]}>
              <TextInput
                placeholder="Enter your User Id"
                style={styles.textInput}
                onChangeText ={(text)=>this.setState({userId : text})}
                value={this.state.userId}
              />
              <TouchableOpacity
                style={{ alignItems: 'center', justifyContent: 'center' }}
                onPress={async() =>{
                   var checkPwd = await this.checkUserId()
                   if(checkPwd){
                      return alert('This User Id already exists')
                   }else{
                      return this.setState({enter: 'Password'})
                   
                   }}}>
                  
                <Text style={styles.textContainer}>Submit</Text>
              </TouchableOpacity>
            </View>
            <View>
              <Text style={{ fontSize: 20, alignSelf: 'center' }}>
                {'<2/4>'}
              </Text>
            </View>
          </KeyboardAvoidingView>
        </ImageBackground>
      );
    }

    if (enter === 'Password') {
      return (
        <ImageBackground
          source={require('../assets/bgImg1.png')}
          style={styles.backgroundImage}>
          <KeyboardAvoidingView style={styles.container}>
            <SafeAreaView />
            <View style={styles.heading}>
              <Text style={styles.headingText}>Sign Up</Text>
            </View>
             <View style={[styles.buttonContainer,{height:"25%"}]}>
              <TextInput
                placeholder="Enter your Email Id"
                style={styles.textInput}
                value={this.state.emailId}
              />
            </View>
            <View style={[styles.buttonContainer,{height:"25%"}]}>
              <TextInput
                placeholder="Enter your User Id"
                style={styles.textInput}
                value={this.state.userId}
              />
            </View>
            <View style={[styles.buttonContainer,{height:"25%"}]}>
              <TextInput
                placeholder="Enter your Password"
                style={styles.textInput}
                secureTextEntry
                onChangeText ={(text)=>this.setState({password : text})}
              />
              <TouchableOpacity
                style={{ alignItems: 'center', justifyContent: 'center' }}
                onPress={async() =>{
                   var checkPwd = await this.checkPassword()
                   if(checkPwd){
                      return alert('This password already exists')
                   }else{
                      return this.setState({enter: 'Confirm'})
                   }
                }}>
                <Text style={styles.textContainer}>Submit</Text>
              </TouchableOpacity>
            </View>

            <View>
              <Text style={{ fontSize: 20, alignSelf: 'center' }}>
                {'<3/4>'}
              </Text>
            </View>
          </KeyboardAvoidingView>
        </ImageBackground>
      );
    }
    if (enter === 'Confirm') {
      return (
        <ImageBackground
          source={require('../assets/bgImg1.png')}
          style={styles.backgroundImage}>
          <KeyboardAvoidingView style={styles.container}>
            <SafeAreaView style={styles.droidSafearea}/>
            <View style={styles.heading}>
              <Text style={styles.headingText}>Sign Up</Text>
            </View>
             <View style={[styles.buttonContainer,{height:"18.75%"}]}>
              <TextInput
                placeholder="Enter your Email Id"
                style={styles.textInput}
                value={this.state.emailId}
              />
            </View>
            <View style={[styles.buttonContainer,{height:"18.75%"}]}>
              <TextInput
                placeholder="Enter your User Id"
                style={[styles.textInput]}
                value={this.state.userId}
              />
            </View>
            <View style={[styles.buttonContainer,{height:"18.75%"}]}>
              <TextInput
                placeholder="Enter your Password"
                style={styles.textInput}
                value={this.state.password}
                secureTextEntry
              />
            </View>
            <View style={[styles.buttonContainer,{height:"18.75%"}]}>
              <TextInput
                placeholder="Confirm your Password"
                style={styles.textInput}
                secureTextEntry
                onChangeText ={(text)=>this.setState({confirm : text})}
              />
              <TouchableOpacity
                style={{ alignItems: 'center', justifyContent: 'center' }}
                onPress={() => {this.state.password == this.state.confirm?this.setState({ enter: 'End' }):alert('Password does not match')}}>
                <Text style={styles.textContainer}>Submit</Text>
              </TouchableOpacity>
            </View>
                
        
              <Text style={{ fontSize: 20, alignSelf: 'center' }}>
                {'<4/4>'}
              </Text>
         
          </KeyboardAvoidingView>
        </ImageBackground>
      );
    }
    if(enter === "End"){
      return(
        <ImageBackground
          source={require('../assets/bgImg1.png')}
          style={styles.backgroundImage}>
          <KeyboardAvoidingView style={styles.container}>
            <SafeAreaView style={styles.droidSafearea}/>
            <View style={styles.heading}>
              <Text style={styles.headingText}>Sign Up</Text>
            </View>
            <TouchableOpacity style={[styles.textContainer,{marginTop:80,alignSelf:'center'}]}
            onPress={()=>this.registerUser()}>
               <Text style={{alignSelf:'center',padding:40,fontSize:40}}>Continue</Text>
            </TouchableOpacity> 
          </KeyboardAvoidingView>
        </ImageBackground>
      )
    }
  }
}

const styles = StyleSheet.create({
  heading: {
    alignSelf: 'center',
    width: '80%',
    height: '15%',
    backgroundColor: 'white',
    borderWidth: 2,
    marginTop: '10%',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
  },
  headingText: {
    fontSize: 30,
    fontFamily: 'Arial Rounded MT ',
  },
  container: {
    width: '100%',
    height: '100%',
    flexDirection: 'column',
    flex: 1,
  },
  backgroundImage: { height: '100%' },

  textInput: {
    height: 50,
    padding: 10,
    borderColor: '#4C5D70',
    borderRadius: 10,
    borderWidth: 3,
    fontSize: 18,
    width: '100%',
    backgroundColor: '#F88379',
    fontFamily: 'Rajdhani_600SemiBold',
    color: '#FFFFFF',
    alignSelf: 'center',
    justifyContent: 'center',
  },
  buttonContainer: {
    width: '85%',
    height: '75%',
    alignSelf: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
  },
  textContainer: {
    borderRadius: 10,
    borderWidth: 3,
    padding: 15,
    backgroundColor: 'orange',
    fontSize: 15,
  },
});
