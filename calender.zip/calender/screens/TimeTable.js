import * as React from 'react'
import {View,Text,TextInput,KeyboardAvoidingView,SafeAreaView,Platform,StatusBar,TouchableOpacity,StyleSheet,ImageBackground}from 'react-native'

import Ionicons from 'react-native-vector-icons/Ionicons';
import db from '../db'
export default class TimeTable extends React.Component{
  constructor(props){
    super(props);
    this.state={
       startTime: '',
       endTime:'',
       day:'',
       agenda:'',
       display: false,
       userId: this.props.navigation.getParam('userId'),
       allDates: [],
       lastVisibleDate: null
    } 
  }
  saveChanges= async() =>{
     const {userId,startTime,endTime,day,agenda} = this.state
     console.log(userId,day)
      db.collection('timeTable')
      .add({
         user_id: this.props.navigation.getParam('userId'),
         start_time: startTime,
         end_time: endTime,
         agenda : agenda,
         day: day
      })
      

  }

   render(){
     const {display,allDates,lastVisibleDate} = this.state
     return(
       <KeyboardAvoidingView behavior={'padding'} style={{height:'100%'}}>
       <ImageBackground source={require('../assets/bg_img3.jpg')} style={{height:"100%",width:"100%"}}>
          <View style={{alignItems:'center',marginBottom:50}}>
            <Text style={{fontSize:30}}>Create Routine</Text>
          </View>
          <View>
            <TextInput style={styles.textInput} placeholder='Enter  day (monday/tuseday etc.)' 
            onChangeText={text=>this.setState({day:text.toLowerCase()})}/>
            <TextInput style={styles.textInput} placeholder='Enter start time(in am/pm)' 
            onChangeText={text=>this.setState({startTime:text})}/>
            <TextInput style={styles.textInput} placeholder='Enter end time(in am/pm)'
            onChangeText={text=>this.setState({endTime:text})}/>
            <TextInput style={styles.textInput} placeholder='Enter Event Name'
            onChangeText={text=>this.setState({agenda:text})}/>
          <View style={{flexDirection:'column',alignItems:'flex-start',width:"50%",alignSelf:'center'}}>
            <TouchableOpacity style={[styles.button,{backgroundColor:'yellow'}]} 
              onPress={()=>this.saveChanges()}>
              <Ionicons name={'save'} size={40}/>
            </TouchableOpacity>
          </View>
            <TouchableOpacity style={[styles.button,{borderWidth:5,backgroundColor:'pink',width:150}]} onPress={()=>this.props.navigation.navigate('HomeScreen')}>
              <Text style={styles.text}>{'Go Back'}</Text>
            </TouchableOpacity>

          </View>
        </ImageBackground>
       </KeyboardAvoidingView>
     )
     
   }
}

const styles = StyleSheet.create({
   textInput:{
     width: "80%",
     height:50,
    borderWidth:3,
    marginTop:30,
    marginLeft: 20,
    padding:10,
    fontSize:16
   },
   button:{
     alignSelf:'center',
     width:60,
     height:60,
     marginTop:30,
     borderWidth:1,
     padding:20,
     alignItems:'center',
     justifyContent:'center',
     marginLeft:5
   },
   text:{
      fontSize:15,
      fontWeight:'bold'
   }
})