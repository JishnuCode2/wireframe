import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  SafeAreaView,
  StatusBar,
  Platform,
  FlatList,
  ImageBackground,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { RFValue } from 'react-native-responsive-fontsize';
import db from '../db';
import { Avatar, ListItem, Icon } from 'react-native-elements';
import CalendarPicker from 'react-native-calendar-picker';
export default class HomeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showTabs: false,
      userId: this.props.navigation.getParam('userId'),
      allDates: [],
      lastVisibleDate: null,
      monday: [],
      tuesday: [],
      wednesday: [],
      thursday: [],
      friday: [],
      saturday: [],
      sunday: [],
      display: '',
    };
  }
  componentDidMount() {
    console.log(Platform.OS);
  }
  getTimetableData = async () => {
    await db
      .collection('timeTable')
      .where('user_id', '==', this.state.userId)
      .get()
      .then((snapshot) => {
        snapshot.docs.map((doc) => {
          const data = doc.data();
          console.log(data)
          if (data.day === 'monday') {
            this.setState({
              monday: [...this.state.monday, doc.data()],
              showTabs: 'timeTable',
            });
            console.log(this.state.monday)
          }
          if (data.day === 'tueday') {
            this.setState({
              tuesday: [...this.state.tuesday, doc.data()],
              showTabs: 'timeTable',
            });
          } else if (data.day === 'wednesday') {
            this.setState({
              wednesday: [...this.state.wednesday, doc.data()],
              showTabs: 'timeTable',
            });
          } else if (data.day === 'thursday') {
            this.setState({
              thursday: [...this.state.thursday, doc.data()],
              showTabs: 'timeTable',
            });
          } else if (data.day === 'friday') {
            this.setState({
              friday: [...this.state.friday, doc.data()],
              showTabs: 'timeTable',
            });
          } else if (data.day === 'saturday') {
            this.setState({
              saturday: [...this.state.saturday, doc.data()],
              showTabs: 'timeTable',
            });
          } else if (data.day === 'sunday') {
            this.setState({
              sunday: [...this.state.sunday, doc.data()],
              showTabs: 'timeTable',
            });
          } else {
            this.setState({showTabs: 'timeTable'})
          }
        });
      });
  };
  /*
   */
  goto = (screen) => {
    console.log(this.state.userId)
    this.props.navigation.navigate(screen, {
      userId: this.state.userId,
      type: 'fromHome',
    });
    this.setState({
      showTabs: false,
    });
  };
  getDates = async () => {
    await db
      .collection('calendars')
      .where('user_id', '==', this.state.userId)
      .get()
      .then((snapshot) => {

        snapshot.docs.map((doc) => {
          this.setState({
            allDates: [...this.state.allDates, doc.data()],
            lastVisibleDate: doc,
            showTabs: 'calendar',
          });
          console.log(this.state.showTabs);
        });
      });
  };
  renderItem = ({ item, i }) => {
    return (
      <ListItem key={i} bottomDivider>
        <ListItem.Content>

            <View style={{ flexDirection: 'row', marginBottom: 12 }}>
              <Text style={{ fontSize: 19 }}>{`Your Agenda:  `}</Text>
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: 300,
                }}>{`${item.agenda}`}</Text>
            </View>
            <Text
              style={{
                fontSize: 19,
                marginLeft: 15,
              }}>{`Start Date: (${item.start_date})`}</Text>
            <Text
              style={{
                fontSize: 19,
                marginLeft: 15,
              }}>{`End Date: (${item.end_date})`}</Text>

        </ListItem.Content>
      </ListItem>
    );
  };
  renderTime = ({ item, i }) => {
    return (
      <ListItem key={i} divider={true}>
        <ListItem.Content>
          <View style={{justifyContent:'center',alignItems:'center',width:150,height:230}}>
            <Text
              style={{
                fontSize: 19,
                marginLeft: 15,
              }}>{`Start Time: (${item.start_time})`}</Text>
            <Text
              style={{
                fontSize: 19,
                marginLeft: 15,
              }}>{`End Time: (${item.end_time})`}</Text>
            <View style={{ flexDirection: 'row', marginBottom: 12 }}>
              <Text style={{ fontSize: 19 }}>{`Your Agenda:  `}</Text>
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: 300,
                }}>{`${item.agenda}`}</Text>
            </View>
          </View>
        </ListItem.Content>
      </ListItem>
    );
  };
  render() {
    if (this.state.showTabs === 'create') {
      return (
        <KeyboardAvoidingView behavior="padding">
          <SafeAreaView style={homeStyles.droidSafearea} />
          <TouchableOpacity
            style={{ height: 30, width: 30, marginLeft: 10 }}
            onPress={() => this.setState({ showTabs: true })}>
            <Ionicons name={'reorder-three-outline'} size={40} />
          </TouchableOpacity>
          <View style={homeStyles.heading}>
            <Text style={homeStyles.headingText}>Your Routines</Text>
          </View>
          <View style={{ marginTop: RFValue(15), alignItems: 'center' }}>
            <TouchableOpacity
              style={[
                homeStyles.button,
                {
                  height: 200,
                  width: '80%',
                  marginLeft: 0,
                  backgroundColor: 'white',
                },
              ]}
              onPress={() =>
                this.props.navigation.navigate('Calender', {
                  userId: this.state.userId,
                })
              }>
              <View style={{ flexDirection: 'column' }}>
                <Text style={[homeStyles.buttonText, { color: 'black' }]}>
                  Create Calender
                </Text>
                <Ionicons size={50} name={'calendar-outline'} />

                <Text
                  style={[
                    homeStyles.buttonText,
                    { fontSize: 10, color: 'black' },
                  ]}>
                  {'<--'}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ marginTop: RFValue(15), alignItems: 'center' }}>
            <TouchableOpacity
              style={[
                homeStyles.button,
                {
                  height: 200,
                  width: '80%',
                  marginLeft: 0,
                  backgroundColor: 'white',
                },
              ]}
              onPress={() =>
                this.props.navigation.navigate('TimeTable', {
                  userId: this.state.userId,
                })
              }>
              <View style={{ flexDirection: 'column' }}>
                <Text style={[homeStyles.buttonText, { color: 'black' }]}>
                  Create Timetable
                </Text>
                <Text
                  style={[
                    homeStyles.buttonText,
                    { fontSize: 10, color: 'black' },
                  ]}>
                  {'<--'}
                </Text>
                <Ionicons size={50} name={'today-outline'} />
              </View>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      );
    } else if (!this.state.showTabs) {
      return (
        <KeyboardAvoidingView behavior="padding" style={{ height: '100%' }}>
          <ImageBackground
            source={require('../assets/bg_img41.jpg')}
            style={{ height: '100%' }}>
            <SafeAreaView style={homeStyles.droidSafearea} />
            <TouchableOpacity
              style={{ height: 30, width: 30, marginLeft: 10 }}
              onPress={() => this.setState({ showTabs: true })}>
              <Ionicons name={'reorder-three-outline'} size={40} />
            </TouchableOpacity>
            <View style={homeStyles.heading}>
              <Text style={homeStyles.headingText}>Your Routines</Text>
            </View>
            <TouchableOpacity
              style={{
                backgroundColor: 'white',
                width: '80%',
                marginLeft: 20,
                height: 60,
                marginTop: 50,
                borderRadius: 5,
                borderWidth: 1,
                justifyContent: 'flex-start',
                flexDirection: 'row',
                alignItems: 'center',
              }}
              onPress={() => this.getDates()}>
              <View style={{ width: '45%' }}>
                <Text style={{ fontSize: 15.5, marginLeft: 20 }}>
                  View Calender Dates
                </Text>
              </View>
              <View style={{ width: '50%', alignItems: 'flex-end' }}>
                <Ionicons size={20} name={'caret-down'} style={{}} />
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={{
                backgroundColor: 'white',
                width: '80%',
                marginLeft: 20,
                height: 60,
                marginTop: 100,
                borderRadius: 5,
                borderWidth: 1,
                justifyContent: 'flex-start',
                flexDirection: 'row',
                alignItems: 'center',
              }}
              onPress={() => this.getTimetableData()}>
              <View style={{ width: '45%' }}>
                <Text style={{ fontSize: 15.5, marginLeft: 20 }}>
                  View TimeTable
                </Text>
              </View>
              <View style={{ width: '50%', alignItems: 'flex-end' }}>
                <Ionicons size={20} name={'caret-down'} style={{}} />
              </View>
            </TouchableOpacity>
          </ImageBackground>
        </KeyboardAvoidingView>
      );
    } else if (this.state.showTabs === 'calendar') {
      return (
        <ImageBackground
          source={require('../assets/bg_img41.jpg')}
          style={{ height: '100%' }}>
          <KeyboardAvoidingView>
            <View
              style={homeStyles.dayContainer}>
              <CalendarPicker
                width={280}
                height={400}
                todayBackgroundColor="white"
                todayTextStyle={{ color: 'black' }}
                allowRangeSelection={true}
              />
            </View>
            <View
              style={{
                alignSelf: 'center',
                borderTopWidth: 1,
                width: '60%',
                marginTop: 10,
              }}>
              <Text
                style={{
                  fontSize: 20,
                  fontFamily: 'Times New Roman',
                  paddingTop: 10,
                  fontWeight: 'bold',
                }}>
                Agendas :--
              </Text>
            </View>
            <FlatList
              style={{
                height: 180,
                backgroundColor: '',
                width: 400,
                alignSelf: 'center',
                borderRadius: 50,
                marginBottom: 20,
                borderWidth: 2,
                borderTopRightRadius: 0,
                borderBottomRightRadius: 0,
              }}
              data={this.state.allDates}
              renderItem={this.renderItem}
              keyExtractor={(item, index) => index.toString()}
            />
            <TouchableOpacity
              style={[
                homeStyles.button2,
                { borderWidth: 5, backgroundColor: 'pink', width: 150 },
              ]}
              onPress={() => this.setState({ showTabs: false, allDates: [] })}>
              <Text>{'Go Back'}</Text>
            </TouchableOpacity>
          </KeyboardAvoidingView>
        </ImageBackground>
      );
    } else if(this.state.showTabs === 'timeTable'){
      return(
        <ImageBackground
          source={require('../assets/bg_img41.jpg')}
          style={{ height: '100%' }}>
          <KeyboardAvoidingView>
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>
                Monday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.monday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>

                Tuesday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.tuesday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>
                Wednesday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.wednesday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>
                Thursday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.thursday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
/>
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>
                Friday:--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.friday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <View
              style={homeStyles.dayContainer}>
              <Text
                style={homeStyles.dayText}>
                Saturday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.saturday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <View style={homeStyles.dayContainer}>
              <Text style={homeStyles.dayText}>
                Sunday :--
              </Text>
            </View>
            <FlatList
              style={homeStyles.flatList}
              horizontal={true}
              data={this.state.sunday}
              renderItem={this.renderTime}
              keyExtractor={(item, index) => index.toString()}
            />
            <TouchableOpacity
              style={[
                homeStyles.button2,
                { borderWidth: 5, backgroundColor: 'pink', width: 150 },
              ]}
              onPress={() => this.setState({ showTabs: false, monday:[]})}>
              <Text>{'Go Back'}</Text>
            </TouchableOpacity>
          </KeyboardAvoidingView>
        </ImageBackground>     
      )
    }
    else {
      return (
        <KeyboardAvoidingView
          style={{ width: '100%', height: '100%', backgroundColor: 'grey' }}
          behavior="padding">
          <SafeAreaView style={homeStyles.droidSafearea} />
          <View
            style={{ width: '80%', height: '100%', backgroundColor: 'white' }}>
            <TouchableOpacity
              style={{ height: 30, width: 30, marginLeft: 10 }}
              onPress={() => this.setState({ showTabs: false })}>
              <Ionicons name={'reorder-three'} size={40} />
            </TouchableOpacity>

            <View
              style={{
                width: '100%',
                backgroundColor: 'black',
                height: 1,
                marginTop: 20,
              }}>
              {' '}
            </View>
            <TouchableOpacity
              style={{ marginTop: 20, marginLeft: 20, flexDirection: 'row' }}
              onPress={() => this.setState({ showTabs: false })}>
              <Ionicons name={'home'} size={30} style={{ marginLeft: 10 }} />
              <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Home</Text>
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                backgroundColor: 'black',
                height: 1,
                marginTop: 20,
              }}>
              {' '}
            </View>
            <TouchableOpacity
              style={{ marginTop: 20, marginLeft: 20, flexDirection: 'row' }}
              onPress={() => this.goto('DetailsScreen')}>
              <Ionicons
                name={'alert-circle'}
                size={30}
                style={{ marginLeft: 10 }}
              />
              <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Details</Text>
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                backgroundColor: 'black',
                height: 1,
                marginTop: 20,
              }}>
              {' '}
            </View>
            <TouchableOpacity
              style={{ marginTop: 20, marginLeft: 20, flexDirection: 'row' }}
              onPress={() => this.setState({ showTabs: 'create' })}>
              <Ionicons name={'build'} size={30} style={{ marginLeft: 10 }} />
              <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Create</Text>
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                backgroundColor: 'black',
                height: 1,
                marginTop: 20,
              }}>
              {' '}
            </View>
          </View>
        </KeyboardAvoidingView>
      );
    }
  }
}

const homeStyles = StyleSheet.create({
  heading: {
    width: '80%',
    height: RFValue(50),
    alignItems: 'center',
    marginTop: RFValue(10),
    justifyContent: 'center',
    borderBottomWidth: 5,
    alignSelf: 'center',
    borderRadius: 120,
    marginBottom: 20,
  },
  headingText: {
    fontSize: RFValue(27),
    fontWeight: 'bold',
    fontFamily: 'Comic Sans MS',
  },
  button: {
    marginLeft: RFValue(20),
    width: RFValue(140),
    backgroundColor: 'blue',
    height: RFValue(100),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    borderWidth: 2,
  },
  button2: {
    alignSelf: 'center',
    width: 60,
    height: 60,
    marginTop: 30,
    borderWidth: 1,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 5,
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
  },
  flatList:{
      height: 230,
      backgroundColor: '',
      width: "60%",
      alignSelf: 'center',
      borderRadius: 50,
      marginBottom: 20,
      borderWidth: 2,

    },
  dayText:{
                  fontSize: 20,
                  fontFamily: 'Times New Roman',
                  paddingTop: 10,
                  fontWeight: 'bold',
                },
  dayContainer:{

                alignSelf: 'center',
                borderTopWidth: 1,
                width: '60%',
                marginTop: 10,
              
              }
});
