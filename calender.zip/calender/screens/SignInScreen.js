import React,{Component} from 'react'
import {Text,View,StyleSheet,Image,ImageBackground,SafeAreaView,Platform,TouchableOpacity,KeyboardAvoidingView,TextInput} from 'react-native'
import {RFValue} from 'react-native-responsive-fontsize' 
import db from '../db'
export default class SignInScreen extends Component{
  constructor(props){
    super(props);
    this.state={
       forgotPassword: false,
       password:'',
       emailId:'',
       userId:''
    }
  }

   checkUserEligibilityForSignIn = async(userId,password,emailId) =>{
     
      const user_id = await db
        .collection('users')
        .where("user_id","==",userId)
        .get()

      const passWord = await db
        .collection('users')
        .where("password","==",password)
        .get()
      const email_id = await db
        .collection('users')
        .where("email_id","==",emailId)
        .get()
        var isEligible
        if(user_id.docs.length === 0 ){
           alert('This user does not exist')
           isEligible=false
        }else if(passWord.docs.length === 0){
           if(email_id.docs.length === 0){
            alert('This user does not exist')
            isEligible = false
           }else{isEligible=true}
        }else{
          isEligible = true
        }
    
       return isEligible
   }

   buttonPress=async()=>{
      const {userId,password,emailId} = this.state
      var start
      if(userId === ''){
         alert('Please enter the User Id')
      }
      if(password === ''){
         if(emailId ===''){
           alert('Please enter the Password/Email Id.')
         }
      }
      if(userId !== ''){
        if(password!==''){
         var isUserEligible = await this.checkUserEligibilityForSignIn(userId,password,emailId)
         console.log(isUserEligible)
         if(isUserEligible){
           console.log(userId)
           this.props.navigation.navigate('HomeScreen',{userId: userId})
          }
        }else if(emailId !== ''){
         var isUserEligible = await this.checkUserEligibilityForSignIn(userId,password,emailId)
         console.log(isUserEligible)
         if(isUserEligible){           console.log(userId)
           this.props.navigation.navigate('HomeScreen',{userId:userId})
          }
        }
      }


   }

   render(){
     const {forgotPassword} = this.state;
      return(
     <ImageBackground 
        source={require('../assets/bgImg1.png')} style={styles.backgroundImage}>
        <KeyboardAvoidingView style={styles.container}>
          <SafeAreaView/>
             <View style={styles.heading}><Text style={styles.headingText}>Sign in</Text></View>
            <View style={{marginTop:200,width:"80%",alignSelf:'center'}}>
               <TextInput placeholder="Enter your User Id" style={styles.textInput}
               onChangeText={text=>{this.setState({userId: text})}}/>
            </View>

          <View style={styles.pwdContainer}>
               <TextInput 
               placeholder={forgotPassword?"Enter your Email Id":"Enter Your Password"} 
               style={styles.textInput}
               onChangeText={text=>{
                  forgotPassword
                  ?[ this.setState({emailId : text,password:''})  ]
                  :[ this.setState({password: text,emailId:''})]
                  console.log(this.state.emailId)
               }}/>
               <TouchableOpacity style={!forgotPassword?[styles.textContainer]:[{}]}
               onPress={()=>this.setState({forgotPassword:true})} disabled={forgotPassword}>
                 <Text style={{fontSize:10}}>{forgotPassword?'':'Forgot password?'}</Text>
               </TouchableOpacity>
            </View>
            <View>
             <TouchableOpacity style={[styles.button, { marginTop: 25 }]} onPress={()=>this.buttonPress()}>
              <Text style={styles.buttonText}>Continue</Text>
             </TouchableOpacity>
            </View>
        </KeyboardAvoidingView>    
    </ImageBackground>
      )
   }
}
const styles=StyleSheet.create({
  heading:{
     alignSelf:'center',
     width:"80%",
     height:50,
     backgroundColor:'white',
     borderWidth: 2,
     marginTop: "10%",
     justifyContent:'center',
     alignItems:'center',
     borderRadius: 20
  },
  headingText:{
    fontSize:30,
    fontFamily: 'Arial Rounded MT '
  },
  container:{width:"100%",height:"100%"},
  backgroundImage:{height:"100%"},

    textInput: {
        height: 50,
        padding: 10,
        borderColor: "#4C5D70",
        borderRadius: 10,
        borderWidth: 3,
        fontSize: 18,
        width:"100%",
        backgroundColor: "#F88379",
        fontFamily: "Rajdhani_600SemiBold",
        color: "#FFFFFF",
        alignSelf:'center',justifyContent:'center'
    },
  pwdContainer:{
     flexDirection:'column',
     marginTop: 50,
     alignSelf:"center",
     width:"80%",
     
  },
  textContainer:{
     backgroundColor:'green',
     width:"40%",
     height:20,
     justifyContent:'center',
     alignItems:'center',
     borderRadius:20,
     borderWidth:1
  },
    button: {
    width: "43%",
    height: 55,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#FBE5C0",
    borderRadius: 20,
    borderWidth: 2,
    borderColor: "#4C5D70",
    alignSelf:'center'
  },
  buttonText: {
    fontSize: 24,
    color: "#4C5D70",
    fontFamily: "Rajdhani_600SemiBold"
  }

})