import * as React from 'react'
import {View,Text,TextInput,TouchableOpacity,SafeAreaView,Platform,StatusBar,StyleSheet} from 'react-native'
import CalendarPicker from 'react-native-calendar-picker'
import db from '../db'
export default class Calender extends React.Component{

  constructor(props) {
    super(props);
    this.state = {
      startDate: null,
      endDate: null,
      agenda: '',
      userId: this.props.navigation.getParam('userId'),
      startTime:'',
      endTime:'',
      sta:0
    };
    this.onDateChange = this.onDateChange.bind(this);
  }

  onDateChange(date, type) {
    if (type === 'END_DATE') {
     const endDate  =  date ? date.toString() : '';
      const end_Date = endDate.split(' ')
      end_Date.splice(5,1)
      end_Date.splice(4,1)
     const end_date = end_Date.join()
     console.log(end_date)
      this.setState({
        endDate: end_date,
      });
    } else {  
     const startDate  =  date ? date.toString() : '';
      const start_Date = startDate.split(' ')
      start_Date.splice(5,1)
      start_Date.splice(4,1)
     const start_date = start_Date.join()
    console.log(start_date)
 
      this.setState({
        startDate: start_date
      });
    }
  }

  saveChanges= async() =>{
    const {startDate,endDate,userId,agenda,startTime,endTime,sta} = this.state

    const start_Date = `${startTime},${startDate}`
    const end_Date = `${endTime},${endDate}`
    console.log(start_Date)
     if(agenda!==''){
      console.log(sta);

      console.log(agenda);
      db.collection('calendars')
      .add({
         user_id: userId,
         start_date: start_Date,
         end_date: end_Date,
         agenda : agenda
      });
     this.setState({
        selectedStartDate: null,
        selectedEndDate: null,
        userId: this.props.navigation.getParam('userId'),
        agenda:'',
        startTime:'',
        endTime:'',
        sta: 1
      });   
     }else{
       return alert('Agenda Name is required')
     }

 
  }
  render(){  
    const { startDate, endDate } = this.state;


    if(this.state.sta === 0){
      return(
   <View>
   
        <CalendarPicker
        height={500}
        todayBackgroundColor ='black'
        todayTextStyle={{color:'white'}}
      allowRangeSelection={true}
           onDateChange={this.onDateChange}
      />

    <View style={{width:"90%",height:1,backgroundColor:'grey',alignSelf:'center',marginTop:40}}>{'  '}</View>

          <View>
          <TextInput style={styles.textinput} placeholder='Enter Start Date/Select the date in the calender'
           value={startDate}/>
          <TextInput style={styles.textinput} placeholder='Enter End Date/Select the date in the calender'
           value={endDate}/>
           <View style={{flexDirection:'row',alignSelf:'center',width:"90%"}}> 
            <TextInput style={[styles.textinput,{marginTop:10,width:"50%",marginLeft:5}]} placeholder="Enter Agenda" onChangeText={(text)=>this.setState({agenda: text})}/>
            <TextInput style={[styles.textinput,{marginTop:10,width:"50%",marginLeft:5}]} placeholder="Enter User Id" value={this.state.userId} onChangeText={text=>this.setState({userId:text})}/>
           </View>
  <TextInput style={styles.textinput} placeholder='Enter Start Time (in a.m/p.m)'
      onChangeText={text=>this.setState({startTime: text})}/>
  <TextInput style={styles.textinput} placeholder='Enter End Time (in a.m/p.m)'
      onChangeText={text=>this.setState({endTime: text})}/>

          <TouchableOpacity style={styles.touchableOpacity} onPress={()=>this.saveChanges()}>
            <Text style={{fontSize:15,color:'white'}}>Save</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.touchableOpacity,{backgroundColor:'green'}]}
           onPress={()=>this.props.navigation.navigate('HomeScreen')}><Text style={{fontSize:15,color:'white'}}>Go Back</Text></TouchableOpacity>
        </View>
      </View>

      )
    }else{
      return(
          <View style={{height:"100%",alignItems:'center',justifyContent:'center',backgroundColor:'black'}}>
            <TouchableOpacity style={{backgroundColor:'white',borderRadius:20,width:250,height:120,alignContent:'center',justifyContent:'center'}} onPress={()=>this.setState({sta: 0})}><Text style={{fontSize:20}}>Changes Saved. Press here to go back</Text></TouchableOpacity>
          </View>
      )
    }


 
    
  }

  
}

const styles = StyleSheet.create({
   textinput:{
     marginTop:10,
     height:40,
     width:"90%",
     marginLeft:10,
     borderColor:'black',
     paddingLeft:5,
     alignSelf:'center',
     borderWidth:1
   },
   touchableOpacity:{
     width:"25%",
     borderWidth:2,
     borderRadius:2,
     alignSelf:'center',
     alignItems:'center',
     justifyContent:'center',
     marginTop:20,
     backgroundColor:'black',
     marginBottom:20,
     height:40
   }
})
