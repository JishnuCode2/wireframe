import React, { Component } from 'react';
import {
  View,
  Text,
  ImageBackground,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Platform,
  StatusBar
} from 'react-native';

export default class Introductions extends Component {
  gotoSignIn = () => {
    this.props.navigation.navigate('SignInScreen');
  };
  gotoSignup = () => {
    this.props.navigation.navigate('SignUpScreen');
  };
  gotoDetails = () => {
    this.props.navigation.navigate('DetailsScreen');
  };


  render() {
    return (
      <View style={{ width: '100%', height: '100%' }}>
        <ImageBackground
          source={require('../assets/bgImg2.png')}
          style={{ height: '100%' }}>
          <SafeAreaView style={styles.droidSafearea}/>
          <TouchableOpacity
            style={{
              backgroundColor: 'blue',
              alignSelf: 'flex-end',
              height: 30,
              marginTop: 20,
              width: 180,
              justifyContent: 'center',
            }}
            onPress={() => this.gotoDetails()}>
            <Text style={{ color: 'white', alignSelf: 'center' }}>
              Press to View details
            </Text>
          </TouchableOpacity>
          <View>
           <Text style={styles.headingText} lineBreakMode={true}>
             Sign in/Sign up and make your own calender
           </Text>
          </View>
          <TouchableOpacity
            style={styles.buttonContainer}
            onPress={() => this.gotoSignup()}>
            <View style={styles.button}>
              <Text style={{ fontWeight: 'bold', fontFamily: 'Arial' }}>
                Sign Up
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.buttonContainer}
            onPress={() => this.gotoSignIn()}>
            <View style={styles.button}>
              <Text style={{ fontWeight: 'bold', fontFamily: 'Arial' }}>
                Sign In
              </Text>
            </View>
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  headingText: {
    marginTop: 90,
    fontSize: 40,
    marginLeft: 30,
    fontWeight: 'bold',
    backgroundColor: '',
    borderRadius: 30,
    backfaceVisibility: false,
  },
  button: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonContainer: {
    marginTop: 50,
    alignItems: 'center',
    backgroundColor: 'orange',
    alignSelf: 'center',
    width: '50%',
    height: 50,
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: 20,
  },
     droidSafearea: {
        marginTop: Platform.OS === "android" ? StatusBar.currentHeight : 0
    },
});
